from django.urls import path
from .import views

urlpatterns = [
    path('',views.home, name= 'home'),
    path('gold-rate/', views.gold_rate, name='gold_rate'),
    path('huid/', views.huid, name='huid'),
    path('calculate/', views.price_calculator, name= 'price_calculator')
]