from django.db import models

class goldrate(models.Model):
    purity_choices = [('24k','24 Karat'),('22k','22 Karat'),('18k','18 Karat'),('14k','14 Karat'),]
    purity = models.CharField(max_length = 3, choices=purity_choices, unique= True)
    rate_per_gram = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.purity} - ₹{self.rate_per_gram}"

class huidverification(models.Model):
    huid_code = models.CharField(max_length=6, unique=True)
    item_description = models.TextField()

    def __str__(self):
        return self.huid_code
