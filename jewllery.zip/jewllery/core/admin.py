from django.contrib import admin
from .models import goldrate, huidverification

admin.site.register(goldrate)
admin.site.register(huidverification)
