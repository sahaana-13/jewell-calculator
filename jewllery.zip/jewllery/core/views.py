from django.shortcuts import render
from .models import *
from decimal import Decimal

def home(request):
    rates = goldrate.objects.all()
    total_price = None
    error = None

    if request.method == "POST":
        try:
            purity = request.POST.get('purity')
            weight = Decimal(request.POST.get('weight', '0'))
            gold_rate = goldrate.objects.get(purity=purity)
            total_price = weight * gold_rate.rate_per_gram
        except Exception as e:
            error = "Invalid input or purity not found."

    return render(request, 'home.html', {
        'rates': rates,
        'total_price': total_price,
        'error': error,
    })

   

def gold_rate(request):
    rates = goldrate.objects.all()
    return render(request, 'gold_rate.html', {'rates':rates})

def huid(request):
   query = request.GET.get('q')
   result = None

   if query:
    try:
        result = huidverification.objects.get(huid_code = query.upper())
    except huidverification.DoesNotExist:
        result = 'not_found'
    
   return render(request, 'huid.html', {'result':result})

from django.shortcuts import render
from .models import goldrate

def price_calculator(request):
    total_price = None
    error = None

    if request.method == 'POST':
        purity = request.POST.get('purity')
        weight = request.POST.get('weight')

        try:
            weight = Decimal(weight)
            rate_obj = goldrate.objects.get(purity=purity)
            rate = rate_obj.rate_per_gram
            total_price = weight * rate
        except  (goldrate.DoesNotExist, ValueError):
            error = "Invalid input. Please check the purity or weight."

    rates = goldrate.objects.all()  # for the dropdown
    return render(request, 'price_calculator.html', {
        'rates': rates,
        'total_price': total_price,
        'error': error
    })
